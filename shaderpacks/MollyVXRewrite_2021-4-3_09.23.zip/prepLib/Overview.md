# Overview

* raymarched atmospheric scattering
* cloud integration and skybox handling overhaul
* update to ACES v1.2 based on the reference implementation provided by the Academy
* fully switch internal rendering to ACEScg for improved dynamic range and color consistency
* pipeline and buffer optimization (maybe? I've seen some things that could potentially be improved/reorganized)

The order here more or less reflects the order in which I'd tackle these things.