import cv2
import numpy as np

blue_noise_img = cv2.imread("noise.png")
gray_noise_img = cv2.imread("gray_noise.png")

(B, G, R) = cv2.split(blue_noise_img)
(B1, G1, R1) = cv2.split(gray_noise_img)



merged = cv2.merge([G1, G, R, R1])

cv2.imshow("Merged", merged)

cv2.imwrite('noise_merged.png', merged)
